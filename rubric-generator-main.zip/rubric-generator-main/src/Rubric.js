class Rubric{
    constructor(){
        this.standard = "";
        this.emerging = "";
        this.developing = "";
        this.exhibiting = "";
        this.exhibitingDepth = "";
    }
}