const { createClient } = require('@supabase/supabase-js');

// Import the Supabase client
const supabaseUrl = process.env.REACT_APP_SUPABASE_URL
const supabaseAnonKey = process.env.REACT_APP_SUPABASE_ANON_KEY

// Create a Supabase client instance
const supabase = createClient(supabaseUrl, supabaseAnonKey)

// Fetch the rows from the "learning_targets" table
async function fetchLearningTargets() {
    try {
        const { data, error } = await supabase.from('learning_targets').select('*');
        
        if (error) {
            throw new Error(error.message);
        }
        
        // Iterate over the rows and display them on the screen
        for (const row of data) {
            console.log(row); // Replace this with your own display logic
        }
    } catch (error) {
        console.error('Error fetching learning targets:', error);
    }
}

// Call the fetchLearningTargets function to start fetching and displaying the rows
fetchLearningTargets();